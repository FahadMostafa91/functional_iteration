L= 2/(1+4^2);
x0=2;
tau=1.0e-10;

for n=1:50
    x1=2*atan(x0);
    errEst=L/(1-L)*abs(x0-x1);
    fprintf('%6d %25.10g %12.5g\n', n, x1, errEst);
    x0=x1;
    if errEst<tau
        break
    end
end 

x0=2^(1/5);
tau=1.0e-10;

for n=1:50
    x1=2*atan(x0);
    errEst=L/(1-L)*abs(x0-x1);
    fprintf('%6d %25.10g %12.5g\n', n, x1, errEst);
    x0=x1;
    if errEst<tau
        break
    end
end 